# Principles

The ten Missional by Design principles for spiritual apps, each with its test question and what it asks the maker to give up.

## Keep the Word distinct, and teach it truly
Every screen teaches. Let readers always tell Scripture from our words, and our words from a machine’s.
- Ask: Can a reader always tell Scripture from our words, and our words from a machine’s?
- Gives up: A cleaner, more confident answer, and the shortcut of a house view presented as neutral.
- https://missional.design/principles/word-distinct/

## Never speak for God
An app may quote, explain, pray the church’s prayers and point. It must never pronounce, promise or plead in God’s name, nor let a persona or a machine take the place of a person or of God.
- Ask: Would we put our own name under this sentence, or are we borrowing God’s?
- Gives up: The engagement a warm persona brings, and the lift of spiritual urgency.
- https://missional.design/principles/speak-for-god/

## Design for the most vulnerable first
Design first for the person most likely to be hurt: in crisis, grieving, abused, scrupulous, new to faith, hurt by a church, or, where an app serves them, a child. Help comes before features, verses or answers.
- Ask: Who is the most vulnerable person likely to use this today, and what will they see?
- Gives up: Speed, and the simplicity of designing for the confident.
- https://missional.design/principles/most-vulnerable/

## Welcome before you ask, and guard what is told in confidence
Let people reach what they came for before asking anything; ask only for what serves them, when it does; and treat what they tell you as holy ground.
- Ask: If a friend read everything we keep about this person, would the person be glad?
- Gives up: Conversion at the front door, and the data that would make the product cleverer or the marketing sharper.
- https://missional.design/principles/welcome/

## Feed the flock, not on it
Attention, time, devotion and money are entrusted, not harvested. Ask for them honestly, never through guilt, fear, urgency or a promise.
- Ask: Does this serve growth in faith, or only the usage numbers?
- Gives up: The daily users, conversions and revenue that pressure would bring.
- https://missional.design/principles/feed-the-flock/

## Make room for rest, and say when it is enough
A faithful product sometimes asks for less: it ends a session, keeps the night quiet, stops asking when the need is met, and lets itself end when its work is done.
- Ask: Where does our product stop, and does it ever tell someone they have done enough?
- Gives up: Time in the app, and the comfort of a product that never has to end.
- https://missional.design/principles/enough/

## Send people to God and to one another
The app is a means, never the destination. Judge it by where people go when they close it.
- Ask: When someone closes what we built, are they closer to God and to other people?
- Gives up: The stickiness of being someone’s only place.
- https://missional.design/principles/send/

## Plant and water; leave the growth to God
Measure what serves the person and the task. Never score a soul, and never claim the fruit as yours.
- Ask: What would we stop measuring if we believed growth is God’s?
- Gives up: The impressive number for the pitch.
- https://missional.design/principles/growth/

## Make it well, as an offering
Craft is worship. Excellence, accessibility, beauty and care are how we love God and the person on the other side of the screen.
- Ask: Would we offer this to God as it is, and could the person with the least sight, time or reading ease use it?
- Gives up: Shipping fast at the cost of the people who cannot use what was shipped.
- https://missional.design/principles/offering/

## Hold it with joy and trembling, before God and others
Rejoice in the work and take its weight: pray for the people who use it, invite those who can say no, confess mistakes plainly, and tend what you release.
- Ask: Who outside the team holds us to account, and who prays for the people who use this?
- Gives up: Speed, control and the credit.
- https://missional.design/principles/trembling/
