# Deep dives

Snapshot of https://missional.design/api/deep-dives.json. Fetch `https://missional.design/api/deep-dives/<slug>.json` for options in full, research and reflection.

## Bible audio (`bible-audio`)
How should Scripture be heard: as text, voice or read-along?
- Options: Text only (Leave it out) · Listen button (Familiar convention) · Read-along (Observed) · Audio first (Observed) · Produced devotional (Observed)
- Decide: Whose voice reads Scripture here, and what happens when it ends?
- https://missional.design/patterns/bible-audio/

## How human the assistant seems (`ai-persona`)
How human should the assistant seem?
- Options: Plain tool (Familiar convention) · Labelled assistant (Familiar convention) · Named assistant (Exploratory) · Persona (Observed) · Companion (Observed) · Biblical character (Observed)
- Decide: Would a reasonable person believe someone who knows, loves or prays for them is here, and can they leave freely?
- https://missional.design/patterns/ai-persona/

## AI personas and roles (`speaking-as`)
In whose name should the assistant speak?
- Options: No speaker (Familiar convention) · A guide (Exploratory) · A friend (Observed) · A church’s teaching (Observed) · A pastor or priest (Observed) · A saint or biblical figure (Observed) · Christ or God (Leave it out)
- Decide: Would your church accept these words if a person said them in that name, and what does the assistant say when asked who it is?
- https://missional.design/patterns/speaking-as/

## Translations (`translations`)
One at a time, side by side or verse by verse?
- Options: One translation (Observed) · Switch in place (Familiar convention) · Verse by verse (Observed) · Parallel panes (Observed) · Interlinear (Familiar convention)
- Decide: Does the reader know what kind of translation this is, and stay on the same verse while comparing?
- https://missional.design/patterns/translations/

## Highlights and notes (`highlights-and-notes`)
How should readers mark a passage?
- Options: Bookmark (Familiar convention) · Highlight (Observed) · Labelled marks (Familiar convention) · Private note (Familiar convention) · Shared note (Observed)
- Decide: Can someone mark in one tap and undo, tell every mark apart without colour, and say exactly who can see each note?
- https://missional.design/patterns/highlights-and-notes/

## Study helps (`study-helps`)
Where should commentary and notes open?
- Options: Preview card (Observed) · Sheet over the text (Observed) · Study panel (Observed) · Full page (Familiar convention) · On request (Observed)
- Decide: Does the reader know who is speaking, which verse the help is about, and how to get back to it?
- https://missional.design/patterns/study-helps/

## Reading plans (`reading-plans`)
What happens when someone misses days?
- Options: Dated plan (Observed) · Sequence (Observed) · Weekly rhythm (Familiar convention) · Daily readings (Familiar convention) · Streak (Observed)
- Decide: After nine days away, does the plan offer a good place to start, or a bill?
- https://missional.design/patterns/reading-plans/

## Prayer (`prayer`)
How can an app make room for prayer?
- Options: Order of prayer (Observed) · Guided steps (Observed) · People I pray for (Observed) · Quiet prayer (Familiar convention) · Counted prayer (Observed)
- Decide: Could someone pray here meaningfully and leave nothing for your dashboard to count?
- https://missional.design/patterns/prayer/

## Check-ins and assessments (`check-ins-and-assessments`)
What may an app ask about someone, and what may it conclude?
- Options: A few setup questions (Observed) · A daily check-in (Observed) · A gifts inventory (Familiar convention) · A church survey (Familiar convention) · A spiritual score (Leave it out)
- Decide: For each question: what does the answer change, who could ever see it, and what does the result claim to know?
- https://missional.design/patterns/check-ins-and-assessments/

## AI memory (`ai-memory`)
What should the assistant know and keep?
- Options: Nothing kept (Familiar convention) · Context you add (Observed) · This conversation (Familiar convention) · Memory you can see (Borrowed) · A profile it builds (Leave it out)
- Decide: Could the person list everything the assistant knows about them, and would they be comfortable if a friend read it?
- https://missional.design/patterns/ai-memory/

## Devotional audio (`devotional-audio`)
Guided prayer, a podcast, a talk or a sleep story?
- Options: Guided prayer (Observed) · Teaching conversation (Familiar convention) · Devotional talk (Observed) · Sleep story (Observed) · Endless stream (Leave it out)
- Decide: After the session, could the listener say what Scripture said, who spoke, and why it ended?
- https://missional.design/patterns/devotional-audio/

## Numbers, headings and notes (`numbers-headings-and-notes`)
How much should surround the text?
- Options: Reader’s edition (Familiar convention) · Verse numbers (Familiar convention) · Section titles (Observed) · Note markers (Observed) · Study layout (Familiar convention) · Inline media (Observed) · Reader decides (Observed)
- Decide: What surrounds the text by default, who wrote it, and can a reader tell it apart and turn it off?
- https://missional.design/patterns/numbers-headings-and-notes/

## How much text at once (`how-much-text`)
One word, a verse, a passage or a whole chapter?
- Options: One word at a time (Borrowed) · One verse at a time (Observed) · One verse in focus (Observed) · One passage (Observed) · Whole chapter (Familiar convention)
- Decide: What unit of Scripture does this screen ask someone to hold in mind, and how do they reach the rest?
- https://missional.design/patterns/how-much-text/

## Finding a passage (`finding-a-passage`)
Browse, type a reference, or start from a need?
- Options: Step by step (Familiar convention) · Expandable book list (Observed) · Type a reference (Borrowed) · Start from a feeling (Observed) · No passage picker (Leave it out)
- Decide: Do most of the people you serve know where they are going, or are they finding out?
- https://missional.design/patterns/finding-a-passage/

## Progress and streaks (`progress-and-streaks`)
What should a reading history show?
- Options: Activity chart (Borrowed) · Levels and badges (Familiar convention) · Book map (Borrowed) · No progress view (Leave it out) · Today’s step (Observed) · Month calendar with a streak (Familiar convention) · Time with Scripture (Borrowed) · Where you keep returning (Borrowed) · Reflection notes (Exploratory)
- Decide: What will this screen say to someone on the day they come back?
- https://missional.design/patterns/progress-and-streaks/

## Citations in AI answers (`ai-citations`)
How should an answer show where it came from?
- Options: Numbered sources (Observed) · Passage cards (Observed) · Scripture quoted in the answer (Exploratory) · No generated answer (Leave it out)
- Decide: When someone may be in danger, what will they see first, and who reviewed it?
- https://missional.design/patterns/ai-citations/

## Sharing with a group (`sharing-with-a-group`)
When someone shares a prayer request, who hears it, and who looks after it?
- Options: Between you and God (Leave it out) · Through a person you choose (Borrowed) · A few people you choose (Observed) · A group with a leader (Observed) · The whole church (Observed) · A public wall (Observed) · Ranked by prayer streaks (Leave it out)
- Decide: When someone shares something hard here, who hears it first, and what are they able, and obliged, to do?
- https://missional.design/patterns/sharing-with-a-group/

## Reading together (`reading-together`)
When people read Scripture together through an app, what do the others see, and who looks after the conversation?
- Options: The same passage, nothing shown (Familiar convention) · A guide for meeting in person (Borrowed) · A group with a leader (Observed) · A plan with friends (Observed) · A feed of friends’ activity (Observed) · A public thread on the verse (Observed)
- Decide: What will each person see of the others’ reading, and who looks after the conversation when it goes wrong?
- https://missional.design/patterns/reading-together/

## First use (`first-use`)
What does someone have to give before they reach what they came for?
- Options: Open on what they came for (Familiar convention) · A first page of places to start (Familiar convention) · Guest first, an account when there is something to keep (Observed) · A short tour first (Observed) · Questions first (Observed) · Asking for payment (Observed)
- Decide: What must someone give before they reach what they came for, and what does it honestly cost you to serve them?
- https://missional.design/patterns/first-use/

## Children and families (`children-and-families`)
When children meet Scripture through an app, who is with them, and what does the app ask of them?
- Options: Read together (Familiar convention) · Family time in a general app (Observed) · A children’s Bible app (Observed) · Games and episodes (Observed) · A youth group with a leader (Observed) · A child alone with an AI (Leave it out)
- Decide: Who is with the child, what does the app ask of them, and who answers when a child is afraid?
- https://missional.design/patterns/children-and-families/

## Giving and offerings (`giving`)
How should a faith app ask for gifts, and what should it never promise?
- Options: Giving stays with the church (Familiar convention) · A quiet way to give (Observed) · The church’s offering (Observed) · A regular gift (Observed) · What a gift does (Observed) · A gift tied to a benefit (Observed) · Pressure and promises (Leave it out)
- Decide: What is chosen for the giver, where does the ask appear, and what does the app say a gift will do?
- https://missional.design/patterns/giving/

## Notifications and reminders (`notifications`)
When may a faith app interrupt someone, in whose voice, and who decides?
- Options: The app waits (Familiar convention) · Their own bell (Observed) · The church’s hours (Familiar convention) · A daily word (Observed) · People, not the app (Observed) · Engagement-driven (Observed) · Messages about the person (Leave it out)
- Decide: Who chose this interruption, how urgent does it claim to be, and what does it say to someone who has stopped coming?
- https://missional.design/patterns/notifications/

## Meeting the person where they are (`meeting-the-person`)
How should the assistant meet each person where they are?
- Options: The same for everyone (Familiar convention) · Reads the message (Borrowed) · Asks before assuming (Exploratory) · Preferences you set (Observed) · Assumed, and shown (Exploratory) · A profile it keeps (Leave it out)
- Decide: What does this assistant assume about the person in front of it, where does that come from, and can they see it, correct it and make it forget?
- https://missional.design/patterns/meeting-the-person/

## Feeds, cards and stories (`verse-feed`)
How should a reader move from one verse to the next?
- Options: The page (Familiar convention) · Pages to turn (Familiar convention) · Cards in order (Observed) · A daily set of stories (Observed) · A feed in order, without end (Observed) · A shuffled, endless feed (Leave it out)
- Decide: How does a reader get from one verse to the next here, how far is each verse from its context, and where does the reading end?
- https://missional.design/patterns/verse-feed/

## Children and AI (`children-and-ai`)
Should a child talk to an AI in a faith app, and who is with them when they do?
- Options: No AI for children (Familiar convention) · AI for the grown-ups (Exploratory) · Ask together (Exploratory) · Written answers (Familiar convention) · A filtered chat for children (Familiar convention) · An open companion (Leave it out)
- Decide: Does a child meet an AI here at all, who is with them when they do, and what happens when they ask it to be their friend or say they are scared?
- https://missional.design/patterns/children-and-ai/

## What the assistant talks about (`chat-scope`)
What will the assistant talk about, and what happens at the edge?
- Options: The passage in front of you (Exploratory) · The Bible and Christian faith (Observed) · Faith and everyday life (Observed) · Hard days, with limits (Borrowed) · A therapist or counsellor (Leave it out) · A spiritual companion (Familiar convention) · Anything at all (Observed)
- Decide: What does this assistant take on, does the person know before they start, and who do they meet at the edge?
- https://missional.design/patterns/chat-scope/

## Agreeing and pushing back (`agreeing-and-pushing-back`)
When should the assistant comfort, question or disagree?
- Options: Always on your side (Leave it out) · Stays with you (Familiar convention) · Agrees, then adds (Observed) · Asks a question back (Borrowed) · Names a disagreement (Exploratory) · Corrects plainly (Familiar convention) · Rebukes and moralises (Leave it out)
- Decide: When will this assistant disagree, how will it say so, and will it hold its position when someone pushes back?
- https://missional.design/patterns/agreeing-and-pushing-back/

## Whose theology (`whose-theology`)
When Christians disagree, whose teaching does the assistant follow?
- Options: One view, unstated (Observed) · One tradition, named (Observed) · Your church (Familiar convention) · Shared faith, then the range (Familiar convention) · You choose a tradition (Observed) · Whatever you believe (Leave it out)
- Decide: Whose teaching does the assistant follow where Christians differ, does the person know before they ask, and does it name the others fairly?
- https://missional.design/patterns/whose-theology/

## Actions on AI answers (`ai-answer-actions`)
Copy, share, try again, report: which belong?
- Options: Every action in a row (Borrowed) · Three, then More (Borrowed) · Actions on the passages (Observed) · No action bar (Leave it out)
- Decide: Which actions does this product need, and what does each one carry with it?
- https://missional.design/patterns/ai-answer-actions/

## Ending the conversation (`ending-the-conversation`)
Who ends the conversation, and may the assistant ask someone to stay?
- Options: Closes well (Exploratory) · Suggests a break (Borrowed) · A length they choose (Borrowed) · Always open (Familiar convention) · One more question (Familiar convention) · A hook at goodbye (Leave it out) · Guilt to stay (Leave it out)
- Decide: Who ends this conversation, and does the ending serve the person or the product?
- https://missional.design/patterns/ending-the-conversation/

## Saying “I don’t know” (`ai-uncertainty`)
How should the assistant show what it does not know?
- Options: Always answers, confidently (Leave it out) · A warning in the fine print (Familiar convention) · A confidence level on each answer (Borrowed) · Says what kind of claim each part is (Exploratory) · Says “I don’t know”, and where to look (Exploratory) · Declines to answer (Observed)
- Decide: When the assistant does not know, does the person find out, and what do they get instead?
- https://missional.design/patterns/ai-uncertainty/

## Spiritual acts and AI (`ai-spiritual-acts`)
Can an AI pray for someone, and what may it say it does?
- Options: Points beyond itself (Exploratory) · The church’s words (Familiar convention) · Helps you find words (Exploratory) · Writes a prayer for you (Observed) · Prays with you (Observed) · Promises to pray (Leave it out) · Blesses or absolves (Leave it out)
- Decide: When someone asks your assistant to pray, who will actually pray, and does the screen tell the truth about it?
- https://missional.design/patterns/ai-spiritual-acts/

## Handing over to people (`handing-over`)
When the assistant points someone to people, what happens next?
- Options: Never mentions people (Familiar convention) · “Talk to someone” (Observed) · Names the right person (Familiar convention) · A message to send (Exploratory) · Their own church, if they ask (Familiar convention) · A person joins (Borrowed) · Passed on without asking (Leave it out)
- Decide: When someone needs a person, who does your assistant point them to, what goes with them, and who decides?
- https://missional.design/patterns/handing-over/

## When the assistant writes first (`assistant-writes-first`)
May the assistant start a conversation, and about what?
- Options: Waits to be asked (Familiar convention) · A check-in they set (Borrowed) · The app’s reminder (Familiar convention) · A daily page from memory (Borrowed) · Follows up on what was shared (Borrowed) · Says it misses them (Leave it out) · Tells someone else (Leave it out)
- Decide: Who chose this message, what did it use from what was confided, and what happens when it goes unanswered?
- https://missional.design/patterns/assistant-writes-first/
