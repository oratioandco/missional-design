Content: Bible & Faith Patterns by Tobias Treppmann, Missional by Design (missional.design), CC BY 4.0. https://creativecommons.org/licenses/by/4.0/
