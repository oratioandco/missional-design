Bible and Faith App Design Patterns
71 original English wireframe boards, each showing three alternatives.
Illustrative data; not product screenshots or validated clinical scripts.
Source register and evidence method are on the website.
A public reuse license for this reference has not yet been set.
